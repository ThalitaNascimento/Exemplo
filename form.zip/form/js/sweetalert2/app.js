var btn = document.getElementById("botao");
btn.onclick = function () {
	swal("Olha So!","Bem Mais Bonitinho","success"); //o success mostra um icone da cor verde
};