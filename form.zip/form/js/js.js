var formularios=document.forms.form;
formularios.onsubmit=function(){
	var senha=formularios.senha.value;
	var senha2=formularios.senha2.value;
	if (senha==senha2){
		alert("cadastro efetuado");
	}else{
		alert("senhas inválidas,tente novamente");
		return false;
	}
};

